from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np

# -------------------------
# Load data
# -------------------------
BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "PooledBeta.csv"

# For Jupyter/Spyder, use this instead:
# BASE_DIR = Path.cwd()
# CSV_PATH = BASE_DIR / "PooledBeta.csv"

df = pd.read_csv(CSV_PATH)

# -------------------------
# Set up subplots
# -------------------------
fig, axes = plt.subplots(
    nrows=3,
    ncols=1,
    figsize=(12, 18),
    sharex=True
)

# -------------------------
# Define beta columns and axis labels
# -------------------------
beta_columns = ['Beta 0', 'Beta 1', 'Beta 2']

label_map = {
    'Beta 0': r'$\mathbf{\beta_0}\;(\mathbf{ln\ count})$',
    'Beta 1': r'$\mathbf{\beta_{11}}\;(\mathbf{ln\ count}/\mathbf{ln\ g})$',
    'Beta 2': r'$\mathbf{\beta_{12}}\;(\mathbf{ln\ count}/\mathbf{ln\ g})$'
}

# -------------------------
# Use consistent color palette for Time groups
# -------------------------
palette = sns.color_palette('Set2')

time_categories = df['Time'].dropna().unique()

time_palette = dict(
    zip(
        time_categories,
        palette[:len(time_categories)]
    )
)

# -------------------------
# Loop through each beta and plot
# -------------------------
for i, beta_col in enumerate(beta_columns):

    ax = axes[i]

    # Plot scatter points
    sns.scatterplot(
        data=df,
        x='Year',
        y=beta_col,
        hue='Time',
        palette=time_palette,
        s=80,
        edgecolor='black',
        ax=ax,
        legend=(i == 2)
    )

    # Add regression lines per Time category
    for time_cat in time_categories:

        sub_df = df[df['Time'] == time_cat]

        sub_df_clean = sub_df.dropna(
            subset=['Year', beta_col]
        )

        if len(sub_df_clean) > 1:

            model = LinearRegression()

            X = sub_df_clean['Year'].values.reshape(-1, 1)
            y = sub_df_clean[beta_col].values

            model.fit(X, y)
            y_pred = model.predict(X)

            # Sort years before plotting regression line
            sort_idx = np.argsort(sub_df_clean['Year'].values)

            ax.plot(
                sub_df_clean['Year'].values[sort_idx],
                y_pred[sort_idx],
                color=time_palette[time_cat],
                linewidth=2
            )

    # Bold axis label only
    ax.set_ylabel(
        label_map[beta_col],
        fontsize=22
    )

    # Axis values are NOT bold
    ax.tick_params(
        axis='both',
        labelsize=20
    )

# -------------------------
# Bottom x-axis label only
# -------------------------
axes[-1].set_xlabel(
    r'$\mathbf{Year}$',
    fontsize=22
)

# -------------------------
# Clean legend
# -------------------------
handles, labels = axes[-1].get_legend_handles_labels()

axes[-1].legend(
    handles=handles[:len(time_categories)],
    labels=labels[:len(time_categories)],
    title='Time',
    fontsize=16,
    title_fontsize=18,
    bbox_to_anchor=(1.001, 1.75),
    loc='upper left'
)

# -------------------------
# Layout adjustment
# -------------------------
plt.tight_layout()
plt.show()