from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
from matplotlib.ticker import FormatStrFormatter

# -------------------------
# File path
# -------------------------
BASE_DIR = Path(__file__).resolve().parent
file_path = BASE_DIR / "PredWeightPooledData.csv"

# For Jupyter/Spyder, use this instead:
# BASE_DIR = Path.cwd()
# file_path = BASE_DIR / "PredWeightPooledData.csv"

# -------------------------
# Read the CSV file
# -------------------------
data = pd.read_csv(file_path)

# -------------------------
# Check required columns
# -------------------------
required_columns = {
    'Breakpoint',
    'Beta 0',
    'Beta 1',
    'Beta 2',
    'Trophic Guild',
    'CommonName'
}

if not required_columns.issubset(data.columns):
    missing = required_columns - set(data.columns)
    raise ValueError(f"Missing required columns: {missing}")

# -------------------------
# Convert numeric columns
# -------------------------
for col in ['Breakpoint', 'Beta 0', 'Beta 1', 'Beta 2']:
    data[col] = pd.to_numeric(data[col], errors='coerce')

# -------------------------
# Axis label map
# -------------------------
label_map = {
    'Beta 0': r'$\mathbf{\beta_0}\;(\mathbf{ln\ count})$',
    'Beta 1': r'$\mathbf{\beta_{11}}\;(\mathbf{ln\ count}/\mathbf{ln\ g})$',
    'Beta 2': r'$\mathbf{\beta_{12}}\;(\mathbf{ln\ count}/\mathbf{ln\ g})$',
    'Breakpoint': r'$\mathbf{W_0^\prime}\;(\mathbf{ln\ g})$'
}

# -------------------------
# Colour-blind-safe palette
# -------------------------
okabe_ito = {
    "Detritivore": "#000000",
    "Herbivore": "#FF7F00",
    "Invertivore": "#A65628",
    "Piscivore": "#FFD700",
    "Planktivore": "#E41A1C",
}

diet_marker_map = {
    "Detritivore": "o",
    "Herbivore": "^",
    "Invertivore": "D",
    "Piscivore": "X",
    "Planktivore": "s",
}

# -------------------------
# Diet order
# -------------------------
ordered_diets = [
    'Detritivore',
    'Planktivore',
    'Herbivore',
    'Invertivore',
    'Piscivore'
]

diets_present = list(pd.unique(data['Trophic Guild'].dropna()))
diets = [d for d in ordered_diets if d in diets_present]

diet_colors = {
    d: okabe_ito.get(d, "#333333")
    for d in diets
}

# -------------------------
# Create figure
# -------------------------
fig = plt.figure(figsize=(16, 18))
gs = fig.add_gridspec(3, 2, width_ratios=[4, 1])

ax1 = fig.add_subplot(gs[0, 0])
ax2 = fig.add_subplot(gs[1, 0])
ax3 = fig.add_subplot(gs[2, 0])

plot_axes = [ax1, ax2, ax3]

legend_ax = fig.add_subplot(gs[:, 1])
legend_ax.axis('off')

# -------------------------
# Function to add trendline
# -------------------------
def add_trendline(ax, x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]

    if x.size < 2:
        return

    X = x.reshape(-1, 1)
    model = LinearRegression()
    model.fit(X, y)

    x_grid = np.linspace(x.min(), x.max(), 200)
    y_pred = model.predict(x_grid.reshape(-1, 1))

    ax.plot(
        x_grid,
        y_pred,
        color='black',
        linestyle='-',
        linewidth=2
    )

# -------------------------
# Draggable labels setup
# -------------------------
draggable_texts = []
dragging = {'text': None}

def place_labels(ax, subset, beta):
    subset = subset.reset_index(drop=True)

    for idx, row in subset.iterrows():
        jitter_x = 0.1 * (idx % 3 - 1)
        jitter_y = 0.1 * ((idx % 5) - 2)

        text = ax.text(
            row['Breakpoint'] + jitter_x,
            row[beta] + jitter_y,
            str(row['CommonName']),
            fontsize=14,
            ha='left',
            va='bottom',
            picker=True
        )

        draggable_texts.append(text)

# -------------------------
# Plot each beta
# -------------------------
beta_columns = ['Beta 0', 'Beta 1', 'Beta 2']

for ax, beta in zip(plot_axes, beta_columns):

    for diet in diets:
        subset = data[data['Trophic Guild'] == diet].dropna(
            subset=['Breakpoint', beta, 'CommonName']
        )

        if subset.empty:
            continue

        ax.scatter(
            subset['Breakpoint'],
            subset[beta],
            label=diet if ax == plot_axes[0] else "",
            color=diet_colors[diet],
            marker=diet_marker_map.get(diet, "o"),
            alpha=0.9,
            s=90,
            edgecolors='black',
            linewidths=1.2
        )

        place_labels(ax, subset, beta)

    xy = data[['Breakpoint', beta]].dropna()

    if not xy.empty:
        add_trendline(
            ax,
            xy['Breakpoint'].values,
            xy[beta].values
        )

    ax.set_ylabel(
        label_map[beta],
        fontsize=18
    )

    ax.tick_params(axis='both', labelsize=18)
    ax.grid(False)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))

# -------------------------
# X-axis labels and ticks
# -------------------------
ax3.set_xlabel(
    label_map['Breakpoint'],
    fontsize=18
)

ax1.set_xticklabels([])
ax2.set_xticklabels([])

bp = data['Breakpoint'].dropna()

if not bp.empty:
    ax_ticks = np.arange(0, np.ceil(bp.max()) + 1, step=2)

    for ax in plot_axes:
        ax.set_xticks(ax_ticks)

# -------------------------
# Legend
# -------------------------
handles, labels = plot_axes[0].get_legend_handles_labels()

legend = legend_ax.legend(
    handles,
    labels,
    title='Trophic Guild',
    loc='center',
    fontsize=18,
    frameon=True,
    framealpha=1,
    markerscale=1.4
)

legend.get_title().set_fontsize(16)
legend.get_title().set_fontweight('bold')
legend.get_frame().set_edgecolor('black')

for handle in legend.legend_handles:
    try:
        handle.set_edgecolor("black")
        handle.set_linewidth(2.0)
    except Exception:
        pass

# -------------------------
# Interactivity: draggable labels
# -------------------------
def on_pick(event):
    if isinstance(event.artist, plt.Text):
        dragging['text'] = event.artist

def on_motion(event):
    if dragging['text'] is not None and event.inaxes:
        dragging['text'].set_position((event.xdata, event.ydata))
        fig.canvas.draw_idle()

def on_release(event):
    dragging['text'] = None

fig.canvas.mpl_connect('pick_event', on_pick)
fig.canvas.mpl_connect('motion_notify_event', on_motion)
fig.canvas.mpl_connect('button_release_event', on_release)

# -------------------------
# Final layout and show
# -------------------------
plt.tight_layout()
plt.subplots_adjust(right=0.85)

plt.show()