from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D

# ============================================================
# 1) Pure NumPy kernel smoother (Gaussian weights)
# ============================================================
def local_kernel_smoother(x, y, x_grid=None, bandwidth=2.0):
    """
    Locally weighted kernel smoother (Gaussian weights).
    - x, y: 1D arrays
    - x_grid: points where to evaluate smooth (defaults to sorted unique x)
    - bandwidth: controls smoothness in x-units (years). Larger = smoother.
    Returns: x_grid (aligned), y_smooth (aligned)
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]

    if x.size < 3:
        return None, None

    order = np.argsort(x)
    x = x[order]
    y = y[order]

    if x_grid is None:
        x_grid = np.unique(x)
    x_grid = np.asarray(x_grid, dtype=float)

    y_smooth = np.empty_like(x_grid, dtype=float)

    for i, x0 in enumerate(x_grid):
        w = np.exp(-0.5 * ((x - x0) / bandwidth) ** 2)
        ws = w.sum()
        if ws <= 0:
            y_smooth[i] = np.nan
        else:
            y_smooth[i] = np.sum(w * y) / ws

    ok2 = np.isfinite(y_smooth)
    return x_grid[ok2], y_smooth[ok2]


# ============================================================
# 2) Uncertainty helpers
# ============================================================
def bootstrap_smoother_ci(x, y, x_grid, bandwidth, n_boot=300, ci=95, seed=42):
    """
    Bootstrap CI for the smoother by resampling (x, y) pairs with replacement.
    Returns: (lo, hi, y_full)
    """
    rng = np.random.default_rng(seed)

    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]

    n = len(x)
    if n < 5:
        return None, None, None

    xs_full, y_full = local_kernel_smoother(x, y, x_grid=x_grid, bandwidth=bandwidth)
    if xs_full is None or y_full is None:
        return None, None, None

    if len(y_full) != len(x_grid):
        y_full = np.interp(x_grid, xs_full, y_full, left=np.nan, right=np.nan)

    boots = np.full((n_boot, len(x_grid)), np.nan, dtype=float)

    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        xs_b, ys_b = local_kernel_smoother(x[idx], y[idx], x_grid=x_grid, bandwidth=bandwidth)
        if xs_b is None or ys_b is None:
            continue
        if len(ys_b) != len(x_grid):
            ys_b = np.interp(x_grid, xs_b, ys_b, left=np.nan, right=np.nan)
        boots[b, :] = ys_b

    alpha = (100 - ci) / 2
    lo = np.nanpercentile(boots, alpha, axis=0)
    hi = np.nanpercentile(boots, 100 - alpha, axis=0)

    return lo, hi, y_full


def loo_influence_max_change(x, y, x_grid, bandwidth):
    """
    Leave-one-out influence metric:
    max absolute deviation between full smooth and any LOO smooth.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x = x[ok]
    y = y[ok]

    n = len(x)
    if n < 5:
        return np.nan

    xs_full, y_full = local_kernel_smoother(x, y, x_grid=x_grid, bandwidth=bandwidth)
    if xs_full is None or y_full is None:
        return np.nan

    if len(y_full) != len(x_grid):
        y_full = np.interp(x_grid, xs_full, y_full, left=np.nan, right=np.nan)

    max_change = 0.0
    for i in range(n):
        mask = np.ones(n, dtype=bool)
        mask[i] = False

        xs_loo, y_loo = local_kernel_smoother(x[mask], y[mask], x_grid=x_grid, bandwidth=bandwidth)
        if xs_loo is None or y_loo is None:
            continue

        if len(y_loo) != len(x_grid):
            y_loo = np.interp(x_grid, xs_loo, y_loo, left=np.nan, right=np.nan)

        change = np.nanmax(np.abs(y_loo - y_full))
        if np.isfinite(change):
            max_change = max(max_change, change)

    return max_change


# ============================================================
# 3) User settings
# ============================================================

# File path
BASE_DIR = Path(__file__).resolve().parent

file_path = BASE_DIR /"EstimTimeSeries1.csv"

# Plot columns
columns_to_plot = ['Beta 0', 'Beta 1', 'Beta 2', 'Breakpoint', 'Breadth']

label_map = {
    'Beta 0': 'β₀ ln(count)',
    'Beta 1': 'β₁ ln(count/g)',
    'Beta 2': 'β₂ ln(count/g)',
    'Breakpoint': 'Breakpoint ln(g)',
    'Breadth': 'Breadth ln(g)'
}

# X limits
year_min = 1987
year_max = 2025

# Smoother controls
bandwidth_years = 2.0
bootstrap_n = 300
bootstrap_ci = 95
show_bootstrap_ci = True
show_loo_influence_text = True

# Guild ordering
diet_order = ["Detritivore", "Planktivore", "Herbivore", "Invertivore", "Piscivore"]

# Okabe–Ito color-blind-safe palette
okabe_ito = {
    "Detritivore": "#000000",  # black
    "Planktivore": "#E41A1C",  # red
    "Herbivore":   "#FF7F00",  # orange
    "Invertivore": "#A65628",  # brown
    "Piscivore":   "#FFD700",  # gold
}

# Marker shapes per guild
diet_marker_map = {
    "Detritivore": "o",
    "Planktivore": "s",
    "Herbivore": "^",
    "Invertivore": "D",
    "Piscivore": "X",
}

# ============================================================
# 4) Read + validate
# ============================================================
data = pd.read_csv(file_path)

required_columns = {
    'Year', 'Beta 0', 'Beta 1', 'Beta 2', 'Breakpoint', 'Breadth',
    'CommonName', 'Trophic Guild', 'Numbers'
}
missing = required_columns - set(data.columns)
if missing:
    raise ValueError(f"Missing columns in CSV: {missing}")

data['Year'] = pd.to_numeric(data['Year'], errors='coerce')

for col in columns_to_plot:
    data[col] = pd.to_numeric(data[col], errors='coerce')

# Keep only rows with key grouping variables
data = data.dropna(subset=['Year', 'CommonName', 'Trophic Guild'])

# Ordering
common_names = sorted(data['CommonName'].unique())
diet_types = [d for d in diet_order if d in data['Trophic Guild'].unique()]
diet_color_map = {d: okabe_ito.get(d, "#333333") for d in diet_types}

# ============================================================
# 5) Plot loop
# ============================================================
for column in columns_to_plot:
    num_species = len(common_names)
    cols = 3
    rows = int(np.ceil(num_species / cols))

    fig, axes = plt.subplots(rows, cols, figsize=(15, 5 * rows), sharex=True)
    axes = np.array(axes).flatten()

    for i, name in enumerate(common_names):
        ax = axes[i]

        subset = data[data['CommonName'] == name].copy()
        subset = subset.dropna(subset=[column])

        # Scatter by trophic guild
        for diet in diet_types:
            diet_subset = subset[subset['Trophic Guild'] == diet]
            if diet_subset.empty:
                continue

            ax.scatter(
                diet_subset['Year'],
                diet_subset[column],
                c=diet_color_map[diet],
                marker=diet_marker_map.get(diet, "o"),
                alpha=0.75,
                s=55,
                edgecolors="black",
                linewidths=0.3
            )

        # Smoothing inputs
        x = subset['Year'].to_numpy(dtype=float)
        y = subset[column].to_numpy(dtype=float)
        ok = np.isfinite(x) & np.isfinite(y)

        if ok.sum() >= 3:
            start_year = int(np.floor(np.min(x[ok])))
            end_year = int(np.ceil(np.max(x[ok])))
            x_grid = np.arange(start_year, end_year + 1, 1.0)

            # Bootstrap CI + main smooth
            if show_bootstrap_ci:
                lo, hi, y_full = bootstrap_smoother_ci(
                    x, y, x_grid,
                    bandwidth=bandwidth_years,
                    n_boot=bootstrap_n,
                    ci=bootstrap_ci,
                    seed=42
                )

                if lo is not None and hi is not None:
                    ax.fill_between(x_grid, lo, hi, color='0.80', alpha=0.6, linewidth=0)

                if y_full is not None:
                    ax.plot(x_grid, y_full, color='black', linestyle='-', linewidth=2.5)
            else:
                xs, ys = local_kernel_smoother(x, y, x_grid=x_grid, bandwidth=bandwidth_years)
                if xs is not None and ys is not None and len(ys) > 1:
                    if len(ys) != len(x_grid):
                        ys = np.interp(x_grid, xs, ys, left=np.nan, right=np.nan)
                    ax.plot(x_grid, ys, color='black', linestyle='-', linewidth=2.5)

            # Leave-one-out influence
            if show_loo_influence_text and ok.sum() >= 5:
                infl = loo_influence_max_change(x, y, x_grid, bandwidth_years)
                if np.isfinite(infl):
                    ax.text(
                        0.02, 0.95, f"LOO max Δ = {infl:.2g}",
                        transform=ax.transAxes,
                        ha="left", va="top",
                        fontsize=10
                    )

        # Titles and axes
        ax.set_title(name, fontsize=14, fontweight='bold')
        ax.tick_params(axis='both', labelsize=14)
        ax.set_xlim(year_min, year_max)
        #ax.set_ylim(bottom=0)

    # Remove unused subplots
    for j in range(num_species, len(axes)):
        fig.delaxes(axes[j])

    # Global y label
    fig.text(
        0.01, 0.5, label_map.get(column, column),
        va='center', rotation='vertical',
        fontsize=20, fontweight='bold'
    )

    # Global x label
    fig.text(0.5, 0.01, 'Year', ha='center', fontsize=20, fontweight='bold')

    # Guild legend
    legend_handles = [
        Line2D(
            [0], [0],
            marker=diet_marker_map.get(d, "o"),
            color='none',
            markerfacecolor=diet_color_map[d],
            markeredgecolor='black',
            markeredgewidth=0.3,
            markersize=10,
            label=d
        )
        for d in diet_types
    ]

    # Trend legend
    extra_handles = []
    extra_labels = []

    if show_bootstrap_ci:
        extra_handles.append(Line2D([0], [0], color='0.80', linewidth=8, alpha=0.6))
        extra_labels.append(f"{bootstrap_ci}% bootstrap band")

    extra_handles.append(Line2D([0], [0], color='black', linewidth=2.5))
    extra_labels.append(f"Main smooth (bw={bandwidth_years:g})")

    bold_font = FontProperties(weight='bold', size=16)

    fig.legend(
        handles=legend_handles,
        title="Trophic Guild",
        title_fontproperties=bold_font,
        loc='center left',
        bbox_to_anchor=(0.84, 0.68),
        fontsize=14,
        frameon=False
    )

    fig.legend(
        handles=extra_handles,
        labels=extra_labels,
        title="Trend",
        title_fontproperties=bold_font,
        loc='center left',
        bbox_to_anchor=(0.84, 0.28),
        fontsize=12,
        frameon=False
    )

    plt.tight_layout(rect=[0.03, 0.03, 0.82, 0.97])
    plt.show()
