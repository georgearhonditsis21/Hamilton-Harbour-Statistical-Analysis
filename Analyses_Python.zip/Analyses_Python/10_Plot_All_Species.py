# Plot_All_Species_Parted_auto_axes.py
# Batches species into 3x3 pages (9 subplots each) and auto-sets per-subplot x limits.
# Y-axis is fixed to [0, 7] for consistent comparison across species.
# Model: y = β0 + β1(x−c) for x ≤ c; y = β0 + β2(x−c) for x ≥ c
# CSV columns required: Common.Name, Period, B0, B1, B2, Bin_change (or "Bin_change (c)")
from pathlib import Path
import os, math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from matplotlib.lines import Line2D

# ---------- FILES ----------
BASE_DIR = Path(__file__).resolve().parent

CSV_PATH = BASE_DIR / "AllSpecies.csv"
OUTDIR   = BASE_DIR

# ---------- CONFIG ----------
ROWS, COLS = 3, 3                 # 9 subplots per page
NPTS = 1800                       # dense sampling improves limit detection
CLIP_NEGATIVE = True              # clip y<0 portions
X_SCAN_MIN, X_SCAN_MAX = -4, 14   # wide scan; xlim will tighten to visible region
X_PAD = 0.10                      # add 10% of visible span as x padding
Y_FIXED = (0, 7)                  # fixed Y axis for all subplots

# Linewidth control:
TIMELINE_LW   = 1.5               # legend (timeline) linewidth
REGRESSION_LW = 1.0               # piecewise regression linewidth (in subplots)

# Period order + solid styles and solid colors across all subplots
PERIOD_ORDER = ["1988–1994", "1995–2004", "2005–2012", "2013–2023"]

# Timeline styles (used in legend). Keep linewidth at 4.5.
PERIOD_STYLES = {
    "1988–1994": {"linestyle": "-", "linewidth": TIMELINE_LW, "alpha": 1.0},
    "1995–2004": {"linestyle": "-", "linewidth": TIMELINE_LW, "alpha": 1.0},
    "2005–2012": {"linestyle": "-", "linewidth": TIMELINE_LW, "alpha": 1.0},
    "2013–2023": {"linestyle": "-", "linewidth": TIMELINE_LW, "alpha": 1.0},
}

# ---------- COLOUR-BLIND SAFE PALETTE (Okabe–Ito) ----------
# https://jfly.uni-koeln.de/color/ (commonly used in scientific plots)
okabe_ito = {
    "blue":        "#0072B2",
    "orange":      "#E69F00",
    "green":       "#009E73",
    "vermillion":  "#D55E00",
    "purple":      "#CC79A7",
    "sky":         "#56B4E9",
    "yellow":      "#F0E442",
    "black":       "#000000",
}

# Map your 4 periods to 4 distinct, color-blind safe colours
PERIOD_COLORS = {
    "1988–1994": okabe_ito["blue"],
    "1995–2004": okabe_ito["orange"],
    "2005–2012": okabe_ito["green"],
    "2013–2023": okabe_ito["vermillion"],
}


# ---------- MODEL ----------
def piecewise_y(x, b0, b1, b2, c):
    x = np.asarray(x)
    return np.where(x <= c, b0 + b1*(x - c), b0 + b2*(x - c))

# ---------- STYLE ----------
def style_axes(ax, title=None, xlim=None, ylim=None):
    if title:
        ax.set_title(title, fontsize=20, pad=6, fontweight='bold')
    ax.tick_params(axis="both", labelsize=18)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    if xlim:
        ax.set_xlim(*xlim)
    if ylim:
        ax.set_ylim(*ylim)
    ax.grid(False)
    for s in ax.spines.values():
        s.set_linewidth(2.0)
        s.set_color("black")
    ax.set_facecolor("white")

# ---------- MAIN ----------
def main():
    if not os.path.exists(CSV_PATH):
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")

    # Robust CSV read
    try:
        df = pd.read_csv(CSV_PATH, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(CSV_PATH, encoding="cp1252")

    # Rename alternative breakpoint column name if needed
    if "Bin_change (c)" in df.columns and "Bin_change" not in df.columns:
        df = df.rename(columns={"Bin_change (c)": "Bin_change"})

    required = ["Common.Name", "Period", "B0", "B1", "B2", "Bin_change"]
    miss = [c for c in required if c not in df.columns]
    if miss:
        raise ValueError(f"CSV missing required columns: {miss}")

    species = sorted(df["Common.Name"].unique(), key=lambda s: s.lower())
    per_page = ROWS * COLS
    batches = math.ceil(len(species) / per_page)
    x_scan = np.linspace(X_SCAN_MIN, X_SCAN_MAX, NPTS)

    print(f"Found {len(species)} species — plotting in {batches} page(s) of {ROWS}x{COLS} subplots...")

    for b in range(batches):
        start, end = b*per_page, min((b+1)*per_page, len(species))
        subset = species[start:end]

        fig, axes = plt.subplots(ROWS, COLS, figsize=(5*COLS, 3.8*ROWS), squeeze=False)
        fig.patch.set_facecolor("white")
        periods_present = set()

        for i, name in enumerate(subset):
            r, c = divmod(i, COLS)
            ax = axes[r][c]

            sub = df[df["Common.Name"] == name].copy()
            sub["Period"] = pd.Categorical(sub["Period"], categories=PERIOD_ORDER, ordered=True)
            sub = sub.sort_values("Period")

            # Track visible x where something is drawn to auto x-limits
            x_visible_mask = np.zeros_like(x_scan, dtype=bool)

            for _, row in sub.iterrows():
                period = str(row["Period"])
                style = PERIOD_STYLES.get(period, {"linestyle": "-", "linewidth": TIMELINE_LW, "alpha": 1.0})
                color = PERIOD_COLORS.get(period, None)

                b0 = float(row["B0"])
                b1 = float(row["B1"])
                b2 = float(row["B2"])
                cc = float(row["Bin_change"])

                y_raw = piecewise_y(x_scan, b0, b1, b2, cc)
                y_plot = np.where(y_raw >= 0, y_raw, np.nan) if CLIP_NEGATIVE else y_raw

                # Piecewise regression line: keep solid color, but linewidth = 2.5
                (line,) = ax.plot(
                    x_scan, y_plot,
                    label=period,
                    color=color,
                    linestyle=style.get("linestyle", "-"),
                    linewidth=REGRESSION_LW,
                    alpha=style.get("alpha", 1.0)
                )

                # Breakpoint line: solid and matches the regression linewidth (2.5) and color
                ax.axvline(
                    cc,
                    linestyle="-",
                    linewidth=TIMELINE_LW,
                    color=line.get_color(),
                    alpha=style.get("alpha", 1.0)
                )

                finite = np.isfinite(y_plot)
                if finite.any():
                    x_visible_mask |= finite
                periods_present.add(period)

            # ----- X LIMITS (per subplot) -----
            if x_visible_mask.any():
                x_vis_min = x_scan[x_visible_mask].min()
                x_vis_max = x_scan[x_visible_mask].max()
                span = max(1e-6, x_vis_max - x_vis_min)
                pad = X_PAD * span
                xlim = (x_vis_min - pad, x_vis_max + pad)
            else:
                xlim = (X_SCAN_MIN, X_SCAN_MAX)

            # ----- FIXED Y LIMITS (for all subplots) -----
            ylim = Y_FIXED

            style_axes(ax, title=name, xlim=xlim, ylim=ylim)

        # Hide unused axes on last page
        for j in range(len(subset), per_page):
            r, c = divmod(j, COLS)
            axes[r][c].axis("off")

        # Shared figure labels (bold)
        fig.supxlabel("ln Body mass (g)", fontsize=22, fontweight='bold', y=0.04)
        fig.supylabel("ln Frequency of occurrence (count)", fontsize=22, fontweight='bold', x=0.02)

        # Shared legend: timeline lines remain thick (4.5)
        handles, labels = [], []
        for p in PERIOD_ORDER:
            if p in periods_present:
                h = Line2D([0], [0], color=PERIOD_COLORS[p], **PERIOD_STYLES[p])
                h.set_label(p)
                handles.append(h); labels.append(p)

        if handles:
            legend = fig.legend(
                handles=handles,
                labels=labels,
                title="Timeline",
                fontsize=15,
                title_fontsize=15,
                frameon=True,
                loc="center right",
                ncol=1,
                bbox_to_anchor=(0.02, 0.5)
            )
            legend.get_title().set_fontweight('bold')
            for text in legend.get_texts():
                text.set_fontweight('bold')
            legend.get_frame().set_edgecolor("black")
            legend.get_frame().set_linewidth(1.6)
            legend.get_frame().set_facecolor("white")

        fig.tight_layout(rect=[0.04, 0.06, 0.98, 0.94])
        outfile = os.path.join(OUTDIR, f"AllSpecies_SegmentedRegression_Part{b+1}.png")
        fig.savefig(outfile, dpi=300, bbox_inches="tight")
        print(f"Saved: {outfile}")

    print("Saved all parts successfully.")

if __name__ == "__main__":
    main()
