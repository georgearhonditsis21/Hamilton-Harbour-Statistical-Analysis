from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np

# Load data
BASE_DIR = Path(__file__).resolve().parent

CSV_PATH = BASE_DIR /"PooledBeta.csv"

df = pd.read_csv(CSV_PATH)

# Set up subplots
fig, axes = plt.subplots(nrows=3, ncols=1, figsize=(12, 18), sharex=True)

# Define beta columns
beta_columns = ['Beta 0', 'Beta 1', 'Beta 2']

# Use consistent color palette for Time groups
palette = sns.color_palette('Set2')
time_categories = df['Time'].dropna().unique()
time_palette = dict(zip(time_categories, palette[:len(time_categories)]))

# Loop through each beta and plot
for i, beta_col in enumerate(beta_columns):
    ax = axes[i]

    # Plot scatter points with Seaborn
    sns.scatterplot(
        data=df,
        x='Year',
        y=beta_col,
        hue='Time',
        palette=time_palette,
        s=80,
        edgecolor='black',
        ax=ax,
        legend=(i == 2)  # Only show legend on last subplot
    )

    # Add custom regression lines per Time category
    for time_cat in time_categories:
        sub_df = df[df['Time'] == time_cat]
        
        # Remove rows with NaN values in 'Year' or the current 'beta_col'
        sub_df_clean = sub_df.dropna(subset=['Year', beta_col])
        
        if len(sub_df_clean) > 1:  # Ensure we have more than one data point for regression
            # Linear Regression for each category
            model = LinearRegression()
            X = sub_df_clean['Year'].values.reshape(-1, 1)  # Predictor (Year)
            y = sub_df_clean[beta_col].values  # Response (Beta values)
            
            model.fit(X, y)  # Fit the model
            y_pred = model.predict(X)  # Predict y using the fitted model
            
            # Plot regression line
            ax.plot(sub_df_clean['Year'], y_pred, color=time_palette[time_cat], linewidth=2)

    ax.set_ylabel(beta_col, fontsize=20, weight='bold')  # Make axis labels bold
    ax.tick_params(axis='both', labelsize=20)

# Only label the x-axis at the bottom
axes[-1].set_xlabel('Year', fontsize=18, weight='bold')  # Make x-axis label bold

# Clean legend (only point markers) and make it float
handles, labels = axes[-1].get_legend_handles_labels()
axes[-1].legend(handles=handles[:len(time_categories)],
                labels=labels[:len(time_categories)],
                title='Time',
                fontsize=16,  # Increased font size for legend items
                title_fontsize=18,  # Increased font size for legend title
                bbox_to_anchor=(1.001, 1.75),  # Float the legend
                loc='upper left')

# Layout adjustment
plt.tight_layout()
plt.show()
