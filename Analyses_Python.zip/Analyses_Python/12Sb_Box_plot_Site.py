from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

# Define file path
BASE_DIR = Path(__file__).resolve().parent

CSV_PATH = BASE_DIR /"Site.csv"

# Read the CSV file
df = pd.read_csv(CSV_PATH)

# Identify the last column (categorical grouping variable)
grouping_col = df.columns[-1]

# Select only numerical columns
numeric_cols = df.select_dtypes(include=['number']).columns

# Reshape data for seaborn
melted_df = df.melt(
    id_vars=[grouping_col],
    value_vars=numeric_cols,
    var_name="Variable",
    value_name="Value"
)

# Use clean white style
sns.set_theme(style="white")

# Create boxplots (NO hue, NO palette)
g = sns.catplot(
    x="Variable",
    y="Value",
    col=grouping_col,
    data=melted_df,
    kind="box",
    col_wrap=4,
    height=6,
    aspect=1.2,
    color="white",
    linewidth=1.5,
    dodge=False
)

# Force black-and-white styling
for ax in g.axes.flat:
    # Boxes
    for patch in ax.patches:
        patch.set_facecolor("white")
        patch.set_edgecolor("black")
        patch.set_linewidth(1.5)

    # Lines (whiskers, medians, caps)
    for line in ax.lines:
        line.set_color("black")
        line.set_linewidth(1.5)

    ax.grid(False)

# Axis labels and titles
g.set_axis_labels("", "Spatial Variability", fontsize=24, fontweight="bold")
g.set_titles("")


# X-axis ticks
for ax in g.axes.flat:
    ax.tick_params(axis='x', labelrotation=90, labelsize=24)
    for label in ax.get_xticklabels():
        label.set_fontweight('bold')

# Y-axis formatting
for ax in g.axes.flat:
    ax.set_yticks([-3, -2, -1, 0, 1, 2, 3])
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.0f'))
    ax.set_ylim(-3, 3)
    ax.tick_params(axis='y', labelsize=24)

    #for label in ax.get_yticklabels():
    #    label.set_fontweight('bold')

# Remove legend
if g._legend is not None:
    g._legend.remove()

# Layout
plt.tight_layout()

# Save figure
output_path = "C:/Users/achie/Desktop/Box_plot/Site_Boxplot.png"
g.savefig(output_path, dpi=300, facecolor="white")

# Show
plt.show()