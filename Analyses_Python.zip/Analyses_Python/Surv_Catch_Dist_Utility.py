# Surv_Catch_Dist_Utility.py
import numpy as np
import pandas as pd

# ============================================================
# 1) SURVIVORSHIP FUNCTIONS
# ============================================================

def clip01(x):
    return np.clip(x, 0.0, 1.0)

def S_weibull(t, alpha, gamma):
    return clip01(np.exp(-((alpha * t) ** gamma)))

# ============================================================
# COLORBLIND FRIENDLY PALETTE (Okabe-Ito)
# ============================================================

CB_COLORS = [
    "#0072B2",  # blue
    "#E69F00",  # orange
    "#009E73",  # bluish green
    "#D55E00",  # vermillion
    "#CC79A7",  # reddish purple
    "#56B4E9",  # sky blue
]

# ============================================================
# 2) SURVIVORSHIP OPTIONS
# ============================================================

def get_default_survivorship_specs():

    return [
        {"name": "Very early steep","func": S_weibull,"params": {"alpha": 2.20,"gamma": 0.45},"color": CB_COLORS[0]},
        {"name": "Exponential-like","func": S_weibull,"params": {"alpha": 0.42,"gamma": 1.00},"color": CB_COLORS[1]},
        {"name": "Mid faster","func": S_weibull,"params": {"alpha": 0.24,"gamma": 3.20},"color": CB_COLORS[2]},
        {"name": "Mid moderate","func": S_weibull,"params": {"alpha": 0.20,"gamma": 2.50},"color": CB_COLORS[3]},
        {"name": "Late slow tail","func": S_weibull,"params": {"alpha": 0.18,"gamma": 1.80},"color": CB_COLORS[4]},
        {"name": "Threshold collapse","func": S_weibull,"params": {"alpha": 0.20,"gamma": 8.00},"color": CB_COLORS[5]},
    ]

# ============================================================
# 2) AXES
# ============================================================

def make_ages(max_age: float, step: float = 0.01):
    """Standardized age in [0,1] and actual age in years."""
    ages_std = np.arange(0.0, 1.0 + step, step)
    ages_actual = ages_std * max_age
    return ages_std, ages_actual


# ============================================================
# 3) GROWTH / WEIGHT
# ============================================================

def vbgf_g(t, k: float, t0: float):
    """g(t) = (1 - exp(-k(t-t0))) clipped at 0."""
    return np.maximum(1.0 - np.exp(-k * (t - t0)), 0.0)


def weight_std_from_g(g, b: float):
    """Standardized weight if W(t)=W_inf*g^b => W_std=g^b."""
    return clip01(g ** b)


# ============================================================
# 4) CATCHABILITY (CORE)
# ============================================================

def catchability(
    L: np.ndarray,
    Const: float,
    PGS_SHA: float,
    beta_L: float,
    beta_L2: float,
    beta_Depth: float,
    beta_Macrophyte: float,
    Depth_value: float,
    Macrophyte_value: float,
    power: float = 2.0,
):
    """
    eta(L) = Const + PGS_SHA + beta_L*L + beta_L2*L^2
             + beta_Depth*Depth + beta_Macrophyte*Macrophyte
    p(L)   = logistic(eta)
    q(L)   = p(L)^power
    """
    eta = (
        Const
        + PGS_SHA
        + beta_L * L
        + beta_L2 * (L ** 2)
        + beta_Depth * Depth_value
        + beta_Macrophyte * Macrophyte_value
    )
    p = 1.0 / (1.0 + np.exp(-eta))
    q = p ** power
    return eta, p, q


# ============================================================
# 4B) CATCHABILITY (Monte Carlo Top-10 helper)
# ============================================================

def monte_carlo_top10_catchability_curves(
    *,
    max_age: float,
    age_step: float,
    L_inf: float,
    k_base: float,
    t0: float,
    # means
    Const: float,
    PGS_SHA: float,
    beta_L: float,
    beta_L2: float,
    beta_Depth: float,
    beta_Macrophyte: float,
    # standard errors
    SE_Const: float,
    SE_PGS_SHA: float,
    SE_beta_L: float,
    SE_beta_L2: float,
    SE_beta_Depth: float,
    SE_beta_Macrophyte: float,
    # covariates
    Depth_value: float,
    Macrophyte_value: float,
    power: float = 2.0,
    # MC settings
    n_samples: int = 200,
    seed: int = 42,
    n_grid: int = 600,
):
    """
    Monte Carlo resampling (Uniform ±1 SE), computes q(L) curves on an L_grid,
    selects TOP 10 curves by highest mean q(L) across L_grid.

    Returns:
      L_grid (n_grid,)
      q_ens (n_samples, n_grid)
      top10_idx (10,)
      df_samples (n_samples, 6)  sampled parameters
      score (n_samples,)         mean q(L) over L_grid
    """
    rng = np.random.default_rng(seed)

    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    g = vbgf_g(ages_actual, k_base, t0)
    length_at_age = L_inf * g
    L_grid = np.linspace(float(length_at_age.min()), float(length_at_age.max()), n_grid)

    means = {
        "Const": Const,
        "PGS_SHA": PGS_SHA,
        "beta_L": beta_L,
        "beta_L2": beta_L2,
        "beta_Depth": beta_Depth,
        "beta_Macrophyte": beta_Macrophyte,
    }
    ses = {
        "Const": SE_Const,
        "PGS_SHA": SE_PGS_SHA,
        "beta_L": SE_beta_L,
        "beta_L2": SE_beta_L2,
        "beta_Depth": SE_beta_Depth,
        "beta_Macrophyte": SE_beta_Macrophyte,
    }

    df_samples = pd.DataFrame({
        name: rng.uniform(means[name] - ses[name], means[name] + ses[name], size=n_samples)
        for name in means
    })

    q_ens = np.zeros((n_samples, L_grid.size), dtype=float)

    for i in range(n_samples):
        _, _, q = catchability(
            L=L_grid,
            Const=float(df_samples.loc[i, "Const"]),
            PGS_SHA=float(df_samples.loc[i, "PGS_SHA"]),
            beta_L=float(df_samples.loc[i, "beta_L"]),
            beta_L2=float(df_samples.loc[i, "beta_L2"]),
            beta_Depth=float(df_samples.loc[i, "beta_Depth"]),
            beta_Macrophyte=float(df_samples.loc[i, "beta_Macrophyte"]),
            Depth_value=Depth_value,
            Macrophyte_value=Macrophyte_value,
            power=power,
        )
        q_ens[i] = q

    score = q_ens.mean(axis=1)
    top10_idx = np.argsort(score)[-10:]
    top10_idx = top10_idx[np.argsort(score[top10_idx])[::-1]]

    return L_grid, q_ens, top10_idx, df_samples, score


def plot_top10_catchability_curves(
    ax,
    L_grid: np.ndarray,
    q_ens: np.ndarray,
    top10_idx: np.ndarray,
    power: float = 2.0,
    title: str = "Top 10 highest catchability curves (by mean q(L))",
):
    """Plot only the TOP 10 curves onto an existing matplotlib axis."""
    for i in top10_idx:
        ax.plot(L_grid, q_ens[i], linewidth=2)
    ax.set_xlabel("Length (cm)")
    ax.set_ylabel(f"q(L) = p(L)^{power:g}")
    ax.set_title(title)
    ax.grid(alpha=0.3)


# ============================================================
# 4C) CHOOSE THE MOST VARIED K CURVES FROM THE TOP-10
# ============================================================

def select_most_varied_from_top10(
    *,
    L_grid: np.ndarray,
    q_ens: np.ndarray,
    top10_idx: np.ndarray,
    k_select: int = 5,
):
    """
    Select k_select catchability curves from the TOP-10 that are maximally varied in shape.

    Method:
      Greedy farthest-point sampling using Euclidean distance between q(L) curves.

    Returns:
      selected_idx : np.ndarray
        Indices into the ORIGINAL ensemble (same index space as top10_idx / q_ens rows).
    """
    top10_idx = np.asarray(top10_idx, dtype=int)
    if top10_idx.ndim != 1:
        raise ValueError("top10_idx must be 1D.")
    if top10_idx.size == 0:
        return np.array([], dtype=int)

    Q = q_ens[top10_idx]
    if Q.ndim != 2:
        raise ValueError("q_ens must be 2D (n_samples, n_grid).")

    diff = Q[:, None, :] - Q[None, :, :]
    dist = np.sqrt(np.sum(diff * diff, axis=2))

    start = int(np.argmax(dist.mean(axis=1)))
    selected = [start]

    while len(selected) < min(int(k_select), Q.shape[0]):
        remaining = [i for i in range(Q.shape[0]) if i not in selected]
        min_d = []
        for r in remaining:
            min_d.append(np.min(dist[r, selected]))
        next_i = remaining[int(np.argmax(min_d))]
        selected.append(next_i)

    return top10_idx[np.array(selected, dtype=int)]


# ============================================================
# 5) DISTRIBUTIONS
# ============================================================

def compute_distribution_vs_length(
    ages_actual,
    S_curve,
    L_inf,
    k,
    t0,
    b,
    Const,
    PGS_SHA,
    beta_L,
    beta_L2,
    beta_Depth,
    beta_Macrophyte,
    Depth_value,
    Macrophyte_value,
    power=2.0,
):
    g = vbgf_g(ages_actual, k, t0)
    L_age = L_inf * g
    W_std = weight_std_from_g(g, b)

    order = np.argsort(L_age)
    Ls = L_age[order]
    Ws = W_std[order]
    Ss = clip01(S_curve)[order]

    _, _, qL = catchability(
        L=Ls,
        Const=Const,
        PGS_SHA=PGS_SHA,
        beta_L=beta_L,
        beta_L2=beta_L2,
        beta_Depth=beta_Depth,
        beta_Macrophyte=beta_Macrophyte,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
    )

    D = Ss * Ws * qL
    return Ls, D


def compute_distribution_vs_weight(
    ages_actual,
    S_curve,
    L_inf,
    k,
    t0,
    a_lw,
    b_lw,
    Const,
    PGS_SHA,
    beta_L,
    beta_L2,
    beta_Depth,
    beta_Macrophyte,
    Depth_value,
    Macrophyte_value,
    power=2.0,
):
    g = vbgf_g(ages_actual, k, t0)
    L_age = L_inf * g

    W_age = a_lw * (L_age ** b_lw)
    W_std = weight_std_from_g(g, b_lw)

    order = np.argsort(W_age)
    Ws = W_age[order]
    Ls = L_age[order]
    Wstds = W_std[order]
    Ss = clip01(S_curve)[order]

    _, _, qL = catchability(
        L=Ls,
        Const=Const,
        PGS_SHA=PGS_SHA,
        beta_L=beta_L,
        beta_L2=beta_L2,
        beta_Depth=beta_Depth,
        beta_Macrophyte=beta_Macrophyte,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
    )

    D = Ss * Wstds * qL
    return Ws, D


# ============================================================
# 5B) Dist vs Weight for Survivorships × selected Catchability sets
# ============================================================

def distributions_vs_weight_for_survivorships_and_top10(
    *,
    ages_actual: np.ndarray,
    survivorship_specs: list,
    L_inf: float,
    k: float,
    t0: float,
    a_lw: float,
    b_lw: float,
    df_samples: pd.DataFrame,
    top10_idx: np.ndarray,
    Depth_value: float,
    Macrophyte_value: float,
    power: float = 2.0,
):
    """
    Returns:
      results[surv_name] = {
        "W": Ws,
        "D_top10": (n_sel, n_points),
        "top10_idx": (n_sel,)
      }
    """
    if not isinstance(df_samples, pd.DataFrame):
        raise TypeError(
            "df_samples must be a pandas DataFrame returned by "
            "monte_carlo_top10_catchability_curves()."
        )

    top10_idx = np.asarray(top10_idx, dtype=int)
    if top10_idx.ndim != 1:
        raise ValueError("top10_idx must be a 1D array of indices.")

    required_cols = {
        "Const", "PGS_SHA", "beta_L", "beta_L2", "beta_Depth", "beta_Macrophyte"
    }
    missing = required_cols - set(df_samples.columns)
    if missing:
        raise ValueError(f"df_samples is missing required columns: {sorted(missing)}")

    g = vbgf_g(ages_actual, k, t0)
    L_age = L_inf * g
    W_age = a_lw * (L_age ** b_lw)
    W_std = weight_std_from_g(g, b_lw)

    order = np.argsort(W_age)
    Ws = W_age[order]
    Ls = L_age[order]
    Wstds = W_std[order]

    results = {}
    n_sel = top10_idx.size

    for spec in survivorship_specs:
        if not isinstance(spec, dict) or "name" not in spec or "func" not in spec:
            raise ValueError(
                "Each survivorship spec must be a dict with keys: "
                "'name' and 'func' (and optional 'params')."
            )

        name = spec["name"]
        func = spec["func"]
        params = spec.get("params", {})

        S_curve = func(ages_actual, **params)
        Ss = clip01(S_curve)[order]

        D_sel = np.zeros((n_sel, Ws.size), dtype=float)

        for r, idx in enumerate(top10_idx):
            row = df_samples.loc[int(idx)]
            _, _, qL = catchability(
                L=Ls,
                Const=float(row["Const"]),
                PGS_SHA=float(row["PGS_SHA"]),
                beta_L=float(row["beta_L"]),
                beta_L2=float(row["beta_L2"]),
                beta_Depth=float(row["beta_Depth"]),
                beta_Macrophyte=float(row["beta_Macrophyte"]),
                Depth_value=Depth_value,
                Macrophyte_value=Macrophyte_value,
                power=power,
            )
            D_sel[r, :] = Ss * Wstds * qL

        results[name] = {
            "W": Ws,
            "D_top10": D_sel,
            "top10_idx": top10_idx,
            "color": spec.get("color", None),
            "params": params,
        }

    return results


# ============================================================
# 5C) RE-INDEX RESULTS BY CATCHABILITY CURVE
# ============================================================

def reindex_distributions_by_catchability(
    results_by_survivorship: dict,
    survivorship_order: list,
):
    """
    Convert:
      results_by_survivorship[surv_name]["D_top10"] shape = (n_sel, n_points)

    Into:
      out = {
        "W": W,
        "top_idx": top_idx (n_sel,),
        "by_catchability": {
            int(top_idx[r]): {
                "D": (n_surv, n_points),
                "survivorship_names": survivorship_order
            },
            ...
        }
      }

    Assumes all survivorships share identical W and identical top10_idx ordering.
    """
    if not survivorship_order:
        raise ValueError("survivorship_order must be a non-empty list of survivorship names.")

    first = results_by_survivorship[survivorship_order[0]]
    W = first["W"]
    top_idx = np.asarray(first["top10_idx"], dtype=int)

    n_sel = top_idx.size
    n_points = W.size
    n_surv = len(survivorship_order)

    for name in survivorship_order:
        if name not in results_by_survivorship:
            raise KeyError(f"Missing survivorship '{name}' in results_by_survivorship.")
        r = results_by_survivorship[name]
        if r["W"].shape != W.shape or not np.allclose(r["W"], W):
            raise ValueError(f"Weight axis W differs for survivorship '{name}'.")
        if (
            np.asarray(r["top10_idx"], dtype=int).shape != top_idx.shape
            or not np.all(np.asarray(r["top10_idx"], dtype=int) == top_idx)
        ):
            raise ValueError(f"top10_idx differs for survivorship '{name}'.")
        if r["D_top10"].shape != (n_sel, n_points):
            raise ValueError(f"D_top10 shape mismatch for survivorship '{name}'.")

    by_catch = {}
    for r_i in range(n_sel):
        D_stack = np.zeros((n_surv, n_points), dtype=float)
        for s_i, sname in enumerate(survivorship_order):
            D_stack[s_i, :] = results_by_survivorship[sname]["D_top10"][r_i, :]
        by_catch[int(top_idx[r_i])] = {
            "D": D_stack,
            "survivorship_names": survivorship_order,
        }

    return {"W": W, "top_idx": top_idx, "by_catchability": by_catch}