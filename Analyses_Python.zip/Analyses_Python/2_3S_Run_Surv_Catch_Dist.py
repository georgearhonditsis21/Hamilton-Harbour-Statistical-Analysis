# run_survivorship_distribution_analysis.py
#
# Usage (from terminal / cmd):
#   python run_survivorship_distribution_analysis.py 1   -> Survivorship plots (2x3)
#   python run_survivorship_distribution_analysis.py 2   -> Growth/Weight vs Age
#   python run_survivorship_distribution_analysis.py 3   -> Top 10 catchability curves (by mean q(L))
#   python run_survivorship_distribution_analysis.py 4   -> Distributions vs Length for each of the top-10 catchabilities (baseline survivorship)
#   python run_survivorship_distribution_analysis.py 5   -> Distributions vs Weight for each of the top-10 catchabilities (baseline survivorship)
#   python run_survivorship_distribution_analysis.py 6   -> Dist vs Weight for SIX survivorship curves × TOP-10 catchability curves
#   python run_survivorship_distribution_analysis.py 7   -> Dist vs Weight for SIX survivorship curves × 6 most varied catchability curves (from top-10)
#   python run_survivorship_distribution_analysis.py 8   -> Dist vs Weight for EACH of 6 varied catchabilities, overlaying ALL 6 survivorship curves
#   python run_survivorship_distribution_analysis.py 9   -> Plot TOP-6 most varied catchability curves (selected from Top-10)
#   python run_survivorship_distribution_analysis.py 10  -> Plot selected catchability curves (idx 13, 30, 45)
#   python run_survivorship_distribution_analysis.py 11  -> Three catchability panels overlaying all 6 survivorship curves
#   python run_survivorship_distribution_analysis.py 12  -> Same as 11, but with fixed axis limits
#
# Notes:
# - Uses the utility module: Surv_Catch_Dist_Utility.py
# - Aligned with the updated Weibull-only survivorship utility.
#
import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from Surv_Catch_Dist_Utility import (
    # survivorship
    S_weibull,
    get_default_survivorship_specs,
    # axes / growth / weight
    make_ages, vbgf_g,
    # distributions
    compute_distribution_vs_length, compute_distribution_vs_weight,
    distributions_vs_weight_for_survivorships_and_top10,
    reindex_distributions_by_catchability,
    # catchability + MC top10 helpers
    monte_carlo_top10_catchability_curves,
    plot_top10_catchability_curves,
    # varied selection
    select_most_varied_from_top10,
)

# ============================================================
# GLOBAL STYLE
# ============================================================
plt.rcParams.update({
    "font.size": 14,
    "axes.labelsize": 16,
    "axes.titlesize": 18,
    "legend.fontsize": 11
})

# ============================================================
# 0) PARAMETERS
# ============================================================

# Ages
max_age = 10
age_step = 0.01

# ----------------------------
# VBGF + L-W parameters
# ----------------------------
L_inf = 72.2
k_base = 0.3
t0 = -0.05
a = 0.01922
b = 2.9333

# ----------------------------
# Catchability coefficients (MEANS)
# ----------------------------
Const = -2.179
PGS_SHA = -0.875
beta_L = 0.146
beta_L2 = -0.0025
beta_Depth = -0.49
beta_Macrophyte = -0.0122

# ----------------------------
# Standard errors (SE) for Monte Carlo
# ----------------------------
SE_Const = 0.368
SE_PGS_SHA = 0.147
SE_beta_L = 0.0292
SE_beta_L2 = 0.000643
SE_beta_Depth = 0.153
SE_beta_Macrophyte = 0.00205

# ----------------------------
# Covariate values
# ----------------------------
Depth_value = 5.0
Macrophyte_value = 0.05
power = 2.0

# ----------------------------
# Monte Carlo settings
# ----------------------------
n_samples = 200
seed = 42
n_grid = 600


# ============================================================
# Helper: build Weibull-only survivorship scenario sets
# ============================================================

def build_survivorship_scenarios(ages_actual: np.ndarray, seed: int = 42, max_lines_per_panel: int = 60):
    """
    Build 6 Weibull-based scenario panels, each varying alpha and gamma
    around the baseline values used in the updated utility script.
    """
    rng = np.random.default_rng(seed)
    levels = 9
    mult = np.geomspace(0.5, 2.0, levels)

    def downsample_options(options, max_lines, keep_first=True):
        if len(options) <= max_lines:
            return options
        if keep_first:
            base = options[0:1]
            rest = options[1:]
            idx = rng.choice(len(rest), size=max_lines - 1, replace=False)
            return base + [rest[i] for i in idx]
        idx = rng.choice(len(options), size=max_lines, replace=False)
        return [options[i] for i in idx]

    base_specs = get_default_survivorship_specs()
    scenario_sets = {}

    for spec in base_specs:
        name = spec["name"]
        alpha0 = spec["params"]["alpha"]
        gamma0 = spec["params"]["gamma"]

        opts = [{
            "label": "baseline",
            "S": S_weibull(ages_actual, alpha0, gamma0),
            "color": spec.get("color", None),
        }]

        for ma in mult:
            for mg in mult:
                a_val = alpha0 * ma
                g_val = gamma0 * mg
                if np.isclose(ma, 1.0) and np.isclose(mg, 1.0):
                    continue
                opts.append({
                    "label": f"α×{ma:.2f}, γ×{mg:.2f}",
                    "S": S_weibull(ages_actual, a_val, g_val),
                    "color": spec.get("color", None),
                })

        scenario_sets[name] = downsample_options(opts, max_lines_per_panel)

    return scenario_sets


# ============================================================
# Mode 1: Survivorship plots (2x3)
# ============================================================

def mode1_survivorship():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    scenario_sets = build_survivorship_scenarios(ages_actual, seed=seed, max_lines_per_panel=60)
    specs = get_default_survivorship_specs()

    fig, axes = plt.subplots(2, 3, figsize=(18, 9), sharex=True, sharey=True)
    axes = axes.ravel()

    for ax, spec in zip(axes, specs):
        key = spec["name"]
        options = scenario_sets[key]
        curve_color = spec.get("color", None)

        for i, opt in enumerate(options):
            if i == 0:
                ax.plot(
                    ages_actual, opt["S"],
                    linewidth=3.0,
                    alpha=1.0,
                    color=curve_color,
                    label="baseline"
                )
            else:
                ax.plot(
                    ages_actual, opt["S"],
                    linewidth=1.0,
                    alpha=0.25,
                    color=curve_color
                )

        ax.set_title(f"{key}\n(n shown = {len(options)})")
        ax.set_xlabel("Age (years)")
        ax.set_ylabel("Survivorship S(t)")
        ax.set_ylim(0, 1.05)
        ax.legend(frameon=False, loc="best")

    plt.suptitle("Weibull Survivorship Parameter Combinations (baseline bold)")
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


# ============================================================
# Mode 2: Growth / Weight vs Age
# ============================================================

def mode2_growth_weight():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)

    g = vbgf_g(ages_actual, k_base, t0)
    L_age = L_inf * g
    W_age = a * (L_age ** b)

    fig, axes = plt.subplots(2, 1, figsize=(11, 8), sharex=True)

    axes[0].plot(ages_actual, L_age, linewidth=2)
    axes[0].set_ylabel("Length (cm)")
    axes[0].set_title("Growth / Weight vs Age")

    axes[1].plot(ages_actual, W_age, linewidth=2)
    axes[1].set_ylabel("Weight (W = a·L^b)")
    axes[1].set_xlabel("Age (years)")

    plt.tight_layout()
    plt.show()


# ============================================================
# Helper: compute Top-10 catchability once
# ============================================================

def compute_top10_catchability():
    L_grid, q_ens, top10_idx, df_samples, score = monte_carlo_top10_catchability_curves(
        max_age=max_age,
        age_step=age_step,
        L_inf=L_inf,
        k_base=k_base,
        t0=t0,
        Const=Const,
        PGS_SHA=PGS_SHA,
        beta_L=beta_L,
        beta_L2=beta_L2,
        beta_Depth=beta_Depth,
        beta_Macrophyte=beta_Macrophyte,
        SE_Const=SE_Const,
        SE_PGS_SHA=SE_PGS_SHA,
        SE_beta_L=SE_beta_L,
        SE_beta_L2=SE_beta_L2,
        SE_beta_Depth=SE_beta_Depth,
        SE_beta_Macrophyte=SE_beta_Macrophyte,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
        n_samples=n_samples,
        seed=seed,
        n_grid=n_grid,
    )
    return L_grid, q_ens, top10_idx, df_samples, score


# ============================================================
# Helper: baseline survivorship
# ============================================================

def baseline_survivorship(ages_actual):
    """
    Use the 'Exponential-like' Weibull curve as the baseline survivorship.
    """
    return S_weibull(ages_actual, alpha=0.35, gamma=1.00)


# ============================================================
# Mode 3: Top 10 Catchability curves
# ============================================================

def mode3_top10_catchability():
    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    fig, ax = plt.subplots(figsize=(11, 6))
    plot_top10_catchability_curves(
        ax=ax,
        L_grid=L_grid,
        q_ens=q_ens,
        top10_idx=top10_idx,
        power=power,
        title="Top 10 highest catchability curves (by mean q(L))",
    )
    plt.tight_layout()
    plt.show()


# ============================================================
# Mode 4: Distributions vs Length (Top-10 catchabilities)
# ============================================================

def mode4_distributions_vs_length_top10():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    S_baseline = baseline_survivorship(ages_actual)

    _, _, top10_idx, df_samples, _ = compute_top10_catchability()

    plt.figure(figsize=(12, 7))
    for rank, idx in enumerate(top10_idx, start=1):
        row = df_samples.loc[idx]

        Ls, D = compute_distribution_vs_length(
            ages_actual=ages_actual,
            S_curve=S_baseline,
            L_inf=L_inf,
            k=k_base,
            t0=t0,
            b=b,
            Const=float(row["Const"]),
            PGS_SHA=float(row["PGS_SHA"]),
            beta_L=float(row["beta_L"]),
            beta_L2=float(row["beta_L2"]),
            beta_Depth=float(row["beta_Depth"]),
            beta_Macrophyte=float(row["beta_Macrophyte"]),
            Depth_value=Depth_value,
            Macrophyte_value=Macrophyte_value,
            power=power,
        )
        plt.plot(Ls, D, linewidth=2, label=f"Rank {rank}")

    plt.xlabel("Length (cm)")
    plt.ylabel("D(L) = S × W_std × q(L)")
    plt.title("Distributions vs Length (Top-10 Catchability Parameter Sets)")
    plt.legend()
    plt.tight_layout()
    plt.show()


# ============================================================
# Mode 5: Distributions vs Weight (Top-10 catchabilities)
# ============================================================

def mode5_distributions_vs_weight_top10():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    S_baseline = baseline_survivorship(ages_actual)

    _, _, top10_idx, df_samples, _ = compute_top10_catchability()

    plt.figure(figsize=(12, 7))
    for rank, idx in enumerate(top10_idx, start=1):
        row = df_samples.loc[idx]

        Ws, D = compute_distribution_vs_weight(
            ages_actual=ages_actual,
            S_curve=S_baseline,
            L_inf=L_inf,
            k=k_base,
            t0=t0,
            a_lw=a,
            b_lw=b,
            Const=float(row["Const"]),
            PGS_SHA=float(row["PGS_SHA"]),
            beta_L=float(row["beta_L"]),
            beta_L2=float(row["beta_L2"]),
            beta_Depth=float(row["beta_Depth"]),
            beta_Macrophyte=float(row["beta_Macrophyte"]),
            Depth_value=Depth_value,
            Macrophyte_value=Macrophyte_value,
            power=power,
        )
        plt.plot(Ws, D, linewidth=2, label=f"Rank {rank}")

    plt.xlabel("Weight (W = a·L^b)")
    plt.ylabel("D(W) = S × W_std × q(L(W))")
    plt.title("Distributions vs Weight (Top-10 Catchability Parameter Sets)")
    plt.legend()
    plt.tight_layout()
    plt.show()


# ============================================================
# Shared: six survivorship specs
# ============================================================

def six_survivorship_specs():
    return get_default_survivorship_specs()


# ============================================================
# Mode 6: SIX survivorship × TOP-10 catchability
# ============================================================

def mode6_survivorships_x_top10_distributions_vs_weight():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    _, _, top10_idx, df_samples, _ = compute_top10_catchability()

    specs = six_survivorship_specs()

    results = distributions_vs_weight_for_survivorships_and_top10(
        ages_actual=ages_actual,
        survivorship_specs=specs,
        L_inf=L_inf,
        k=k_base,
        t0=t0,
        a_lw=a,
        b_lw=b,
        df_samples=df_samples,
        top10_idx=top10_idx,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
    )

    fig, axes = plt.subplots(2, 3, figsize=(18, 9), sharex=False, sharey=False)
    axes = axes.ravel()

    for ax, spec in zip(axes, specs):
        name = spec["name"]
        W = results[name]["W"]
        D_top = results[name]["D_top10"]
        curve_color = spec.get("color", None)

        for r in range(D_top.shape[0]):
            ax.plot(W, D_top[r], linewidth=1.8, alpha=0.9, color=curve_color)

        ax.set_title(f"{name}\n(Top-{D_top.shape[0]} catchability curves)")
        ax.set_xlabel("Weight (W = a·L^b)")
        ax.set_ylabel("D(W) = S × W_std × q(L(W))")

    plt.suptitle("Distribution vs Weight: SIX Weibull Survivorship Curves × TOP-10 Catchability Curves")
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


# ============================================================
# Mode 7: SIX survivorship × 6 most varied catchability
# ============================================================

def mode7_survivorships_x_top6_varied_distributions_vs_weight():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    L_grid, q_ens, top10_idx, df_samples, _ = compute_top10_catchability()

    top6_varied_idx = select_most_varied_from_top10(
        L_grid=L_grid, q_ens=q_ens, top10_idx=top10_idx, k_select=6
    )

    specs = six_survivorship_specs()

    results = distributions_vs_weight_for_survivorships_and_top10(
        ages_actual=ages_actual,
        survivorship_specs=specs,
        L_inf=L_inf,
        k=k_base,
        t0=t0,
        a_lw=a,
        b_lw=b,
        df_samples=df_samples,
        top10_idx=top6_varied_idx,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
    )

    fig, axes = plt.subplots(2, 3, figsize=(18, 9), sharex=False, sharey=False)
    axes = axes.ravel()

    for ax, spec in zip(axes, specs):
        name = spec["name"]
        W = results[name]["W"]
        D_sel = results[name]["D_top10"]
        chosen = results[name]["top10_idx"]
        curve_color = spec.get("color", None)

        for r in range(D_sel.shape[0]):
            ax.plot(
                W, D_sel[r],
                linewidth=2.0,
                alpha=0.95,
                color=curve_color,
                label=f"Varied {r+1} (idx {int(chosen[r])})"
            )

        ax.set_title(f"{name}\n(6 most varied from top-10)")
        ax.set_xlabel("Weight (W = a·L^b)")
        ax.set_ylabel("D(W) = S × W_std × q(L(W))")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8, loc="best")

    plt.suptitle("Distribution vs Weight: SIX Weibull Survivorship Curves × 6 Most Varied Catchability Curves")
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


# ============================================================
# Mode 8: For EACH of 6 varied catchabilities, overlay ALL 6 survivorships
# ============================================================

def mode8_top6_varied_catchabilities_overlay_6_survivorships():
    _, ages_actual = make_ages(max_age=max_age, step=age_step)
    L_grid, q_ens, top10_idx, df_samples, _ = compute_top10_catchability()

    top6_varied_idx = select_most_varied_from_top10(
        L_grid=L_grid, q_ens=q_ens, top10_idx=top10_idx, k_select=6
    )

    specs = six_survivorship_specs()
    surv_names = [s["name"] for s in specs]
    surv_colors = [s.get("color", None) for s in specs]

    results_by_surv = distributions_vs_weight_for_survivorships_and_top10(
        ages_actual=ages_actual,
        survivorship_specs=specs,
        L_inf=L_inf,
        k=k_base,
        t0=t0,
        a_lw=a,
        b_lw=b,
        df_samples=df_samples,
        top10_idx=top6_varied_idx,
        Depth_value=Depth_value,
        Macrophyte_value=Macrophyte_value,
        power=power,
    )

    catch_view = reindex_distributions_by_catchability(results_by_surv, survivorship_order=surv_names)
    W = catch_view["W"]
    chosen = list(catch_view["by_catchability"].keys())

    fig, axes = plt.subplots(2, 3, figsize=(18, 9), sharex=False, sharey=False)
    axes = axes.ravel()

    for p, catch_idx in enumerate(chosen):
        ax = axes[p]
        D_stack = catch_view["by_catchability"][catch_idx]["D"]
        names = catch_view["by_catchability"][catch_idx]["survivorship_names"]

        for s_i, sname in enumerate(names):
            ax.plot(
                W, D_stack[s_i, :],
                linewidth=2.0,
                alpha=0.95,
                color=surv_colors[s_i],
                label=sname
            )

        ax.set_title(f"Catchability curve (idx {catch_idx})\nOverlay 6 survivorships")
        ax.set_xlabel("Weight (W = a·L^b)")
        ax.set_ylabel("D(W) = S × W_std × q(W)")
        ax.legend(fontsize=8, loc="best")

    for p in range(len(chosen), len(axes)):
        axes[p].axis("off")

    plt.suptitle("Distribution vs Weight: EACH of 6 Varied Catchabilities × Overlay 6 Survivorship Curves")
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()


# ============================================================
# Mode 9: Plot TOP-6 most varied catchability curves
# ============================================================

def mode9_top6_most_varied_catchability():
    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    top6_varied_idx = select_most_varied_from_top10(
        L_grid=L_grid,
        q_ens=q_ens,
        top10_idx=top10_idx,
        k_select=6
    )

    fig, ax = plt.subplots(figsize=(11, 6))

    for rank, idx in enumerate(top6_varied_idx, start=1):
        ax.plot(
            L_grid,
            q_ens[int(idx), :],
            linewidth=2.2,
            alpha=0.95,
            label=f"Varied {rank} (idx {int(idx)})"
        )

    ax.set_title("Top 6 most varied catchability curves (selected from Top-10)")
    ax.set_xlabel("Length (cm)")
    ax.set_ylabel("Catchability q(L)")
    ax.legend(fontsize=9, loc="best")

    plt.tight_layout()
    plt.show()


# ============================================================
# Mode 10: Plot selected catchability curves (idx 13, 30, 45)
# ============================================================

def mode10_selected_catchability():
    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    selected_idx = [13, 30, 45]
    linestyles = ['-', '--', ':']

    fig, ax = plt.subplots(figsize=(11, 6))

    for i, (idx, ls) in enumerate(zip(selected_idx, linestyles), start=1):
        ax.plot(
            L_grid,
            q_ens[int(idx), :],
            linewidth=2.6,
            linestyle=ls,
            color='black',
            alpha=0.95,
            label=f"Catchability {i}"
        )

    ax.set_title("Selected Catchability Curves", fontsize=22, fontweight="bold")
    ax.set_xlabel("Length (cm)", fontsize=18, fontweight="bold")
    ax.set_ylabel("Catchability q(L)", fontsize=18, fontweight="bold")
    ax.tick_params(labelsize=16)

    plt.tight_layout()
    plt.show()


# ============================================================
# Mode 11: Three catchability panels overlaying 6 survivorships
# ============================================================

def mode11_three_catchability_panels_overlay_6_survivorships():
    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    selected_idx = [13, 30, 45]
    catch_linestyles = ['-', '--', ':']

    _, ages_actual = make_ages(max_age=max_age, step=age_step)

    g = vbgf_g(ages_actual, k_base, t0)
    L_age = L_inf * g
    W_age = a * (L_age ** b)
    W_std = np.clip(g ** b, 0.0, 1.0)

    order = np.argsort(W_age)
    W_age_s = W_age[order]
    L_age_s = L_age[order]
    W_std_s = W_std[order]

    specs = six_survivorship_specs()
    surv_names = [s["name"] for s in specs]
    surv_colors = [s.get("color", None) for s in specs]

    S_curves_sorted = []
    for spec in specs:
        S_curve = spec["func"](ages_actual, **spec["params"])
        S_curve = np.asarray(S_curve)[order]
        S_curves_sorted.append(S_curve)

    fig, axes = plt.subplots(1, 3, figsize=(20, 6), sharex=True, sharey=True)

    for i, (ax, idx, ls) in enumerate(zip(axes, selected_idx, catch_linestyles), start=1):
        q_curve = q_ens[int(idx), :]

        for S_s, sname, scol in zip(S_curves_sorted, surv_names, surv_colors):
            q_at_L_s = np.interp(L_age_s, L_grid, q_curve)
            D_W = S_s * W_std_s * q_at_L_s

            ax.plot(
                W_age_s,
                D_W,
                linewidth=3.5,
                alpha=0.95,
                linestyle=ls,
                color=scol,
                label=sname
            )

        ax.tick_params(axis='both', labelsize=16)

        if i == 1:
            ax.set_ylabel("D = S × W_std × q", fontsize=18, fontweight="bold")

        for spine in ax.spines.values():
            spine.set_linewidth(1.2)

    fig.supxlabel("Weight (g)", fontsize=18, fontweight="bold")

    legend_x = 0.86

    catch_handles = [
        Line2D([0], [0], color="black", lw=2.5, linestyle='-',  label="Catchability 1"),
        Line2D([0], [0], color="black", lw=2.5, linestyle='--', label="Catchability 2"),
        Line2D([0], [0], color="black", lw=2.5, linestyle=':',  label="Catchability 3"),
    ]
    legend_catch = fig.legend(
        handles=catch_handles,
        loc="upper left",
        bbox_to_anchor=(legend_x, 0.82),
        ncol=1,
        fontsize=14,
        frameon=False
    )

    handles_surv, labels_surv = axes[0].get_legend_handles_labels()
    legend_surv = fig.legend(
        handles_surv,
        labels_surv,
        loc="upper left",
        bbox_to_anchor=(legend_x, 0.55),
        ncol=1,
        fontsize=14,
        frameon=False
    )

    fig.add_artist(legend_catch)
    fig.add_artist(legend_surv)

    plt.suptitle(
        "Size Distribution of Gizzard Shad: Three Catchability and Six Survivorship Scenario",
        fontsize=20,
        fontweight="bold"
    )

    plt.tight_layout(rect=[0.02, 0.06, 0.84, 0.93])
    plt.show()


# ============================================================
# Mode 12: Same as Mode 11, with fixed axis limits
# ============================================================

def mode12_three_catchability_panels_overlay_6_survivorships():
    X_MIN, X_MAX = 0, 6000
    Y_MIN, Y_MAX = 0, 0.04

    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    selected_idx = [13, 30, 45]
    catch_linestyles = ['-', '--', ':']

    _, ages_actual = make_ages(max_age=max_age, step=age_step)

    g = vbgf_g(ages_actual, k_base, t0)
    L_age = L_inf * g
    W_age = a * (L_age ** b)
    W_std = np.clip(g ** b, 0.0, 1.0)

    order = np.argsort(W_age)
    W_age_s = W_age[order]
    L_age_s = L_age[order]
    W_std_s = W_std[order]

    specs = six_survivorship_specs()
    surv_names = [s["name"] for s in specs]
    surv_colors = [s.get("color", None) for s in specs]

    S_curves_sorted = []
    for spec in specs:
        S_curve = spec["func"](ages_actual, **spec["params"])
        S_curve = np.asarray(S_curve)[order]
        S_curves_sorted.append(S_curve)

    fig, axes = plt.subplots(1, 3, figsize=(20, 6), sharex=True, sharey=True)

    for i, (ax, idx, ls) in enumerate(zip(axes, selected_idx, catch_linestyles), start=1):
        q_curve = q_ens[int(idx), :]

        for S_s, sname, scol in zip(S_curves_sorted, surv_names, surv_colors):
            q_at_L_s = np.interp(L_age_s, L_grid, q_curve)
            D_W = S_s * W_std_s * q_at_L_s

            ax.plot(
                W_age_s,
                D_W,
                linewidth=2.2,
                alpha=0.95,
                linestyle=ls,
                color=scol,
                label=sname
            )

        ax.tick_params(axis='both', labelsize=16)
        #ax.set_xlim(X_MIN, X_MAX)
        #ax.set_ylim(Y_MIN, Y_MAX)

        if i == 1:
            ax.set_ylabel("D(W) = S × W* × q", fontsize=18, fontweight="bold")

        for spine in ax.spines.values():
            spine.set_linewidth(1.2)

    fig.supxlabel("Weight (g)", fontsize=18, fontweight="bold")

    legend_x = 0.86

    catch_handles = [
        Line2D([0], [0], color="black", lw=2.5, linestyle='-',  label="Catchability 1"),
        Line2D([0], [0], color="black", lw=2.5, linestyle='--', label="Catchability 2"),
        Line2D([0], [0], color="black", lw=2.5, linestyle=':',  label="Catchability 3"),
    ]
    legend_catch = fig.legend(
        handles=catch_handles,
        loc="upper left",
        bbox_to_anchor=(legend_x, 0.82),
        ncol=1,
        fontsize=14,
        frameon=False
    )

    handles_surv, labels_surv = axes[0].get_legend_handles_labels()
    legend_surv = fig.legend(
        handles_surv,
        labels_surv,
        loc="upper left",
        bbox_to_anchor=(legend_x, 0.55),
        ncol=1,
        fontsize=14,
        frameon=False
    )

    fig.add_artist(legend_catch)
    fig.add_artist(legend_surv)

    plt.suptitle(
        "Size Distribution of Gizzard Shad: Three Catchability and Six Survivorship Scenario",
        fontsize=20,
        fontweight="bold"
    )

    plt.tight_layout(rect=[0.02, 0.06, 0.84, 0.93])
    plt.show()

# ============================================================
# Model 13: Plot selected catchability curves (idx 13, 30, 45)
#           expressed as a function of weight
# ============================================================

def mode13_selected_catchability_weight():

    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    selected_idx = [13, 30, 45]
    linestyles = ['-', '--', ':']

    # ------------------------------------------------
    # Convert length to weight using W = aL^b
    # ------------------------------------------------
    W_grid = a * (L_grid ** b)

    fig, ax = plt.subplots(figsize=(11, 6))

    for i, (idx, ls) in enumerate(zip(selected_idx, linestyles), start=1):
        ax.plot(
            W_grid,
            q_ens[int(idx), :],
            linewidth=2.6,
            linestyle=ls,
            color='black',
            alpha=0.95,
            label=f"Catchability {i}"
        )

    ax.set_title("Selected Catchability Curves", fontsize=26, fontweight="bold")
    ax.set_xlabel("Weight (g)", fontsize=24, fontweight="bold")
    ax.set_ylabel("Catchability q(W)", fontsize=24, fontweight="bold")

    ax.tick_params(labelsize=20)

    plt.tight_layout()
    plt.show()
# ============================================================
# Model 14: Catchability as a function of Length and Weight
# ============================================================

def mode14_catchability_length_vs_weight():

    L_grid, q_ens, top10_idx, _, _ = compute_top10_catchability()

    selected_idx = [13, 30, 45]
    linestyles = ['-', '--', ':']

    # --------------------------------------------
    # Convert length to weight
    # --------------------------------------------
    W_grid = a * (L_grid ** b)

    fig, axes = plt.subplots(1, 2, figsize=(13, 6), sharey=True)

    ax1, ax2 = axes

    # --------------------------------------------
    # Plot curves
    # --------------------------------------------
    for i, (idx, ls) in enumerate(zip(selected_idx, linestyles), start=1):

        q_vals = q_ens[int(idx), :]

        # Length plot
        ax1.plot(
            L_grid,
            q_vals,
            linewidth=2.6,
            linestyle=ls,
            color='black',
            alpha=0.95,
            label=f"Catchability {i}"
        )

        # Weight plot
        ax2.plot(
            W_grid,
            q_vals,
            linewidth=2.6,
            linestyle=ls,
            color='black',
            alpha=0.95,
            label=f"Catchability {i}"
        )

    # --------------------------------------------
    # Titles
    # --------------------------------------------
    ax1.set_title("Catchability vs Length", fontsize=22, fontweight="bold")
    ax2.set_title("Catchability vs Weight", fontsize=22, fontweight="bold")

    # --------------------------------------------
    # Axis labels
    # --------------------------------------------
    ax1.set_xlabel("Length (cm)", fontsize=22, fontweight="bold")
    ax2.set_xlabel("Weight (g)", fontsize=22, fontweight="bold")

    ax1.set_ylabel("Catchability q", fontsize=22, fontweight="bold")

    # --------------------------------------------
    # Tick size
    # --------------------------------------------
    for ax in axes:
        ax.tick_params(labelsize=18)

    # --------------------------------------------
    # Legend (only once)
    # --------------------------------------------
    #ax2.legend(fontsize=11, loc="best")

    plt.tight_layout()
    plt.show()
# ============================================================
# Main
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("Provide a mode number: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 or 13")
        sys.exit(1)

    try:
        mode = int(sys.argv[1])
    except ValueError:
        print("Mode must be an integer: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 or 13")
        sys.exit(1)

    if mode == 1:
        mode1_survivorship()
    elif mode == 2:
        mode2_growth_weight()
    elif mode == 3:
        mode3_top10_catchability()
    elif mode == 4:
        mode4_distributions_vs_length_top10()
    elif mode == 5:
        mode5_distributions_vs_weight_top10()
    elif mode == 6:
        mode6_survivorships_x_top10_distributions_vs_weight()
    elif mode == 7:
        mode7_survivorships_x_top6_varied_distributions_vs_weight()
    elif mode == 8:
        mode8_top6_varied_catchabilities_overlay_6_survivorships()
    elif mode == 9:
        mode9_top6_most_varied_catchability()
    elif mode == 10:
        mode10_selected_catchability()
    elif mode == 11:
        mode11_three_catchability_panels_overlay_6_survivorships()
    elif mode == 12:
        mode12_three_catchability_panels_overlay_6_survivorships()
    elif mode == 13:
        mode13_selected_catchability_weight()
    elif mode == 14:
        mode14_catchability_length_vs_weight()
    else:
        print("Unknown mode. Use 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, or 14.")
        sys.exit(1)

if __name__ == "__main__":
    main()