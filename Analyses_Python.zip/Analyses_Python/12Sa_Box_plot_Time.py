from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

# Define file path
BASE_DIR = Path(__file__).resolve().parent

CSV_PATH = BASE_DIR /"Time.csv"

# Read the CSV file
df = pd.read_csv(CSV_PATH)

# Identify the last column (categorical grouping variable)
grouping_col = df.columns[-1]

# Select only numerical columns
numeric_cols = df.select_dtypes(include=['number']).columns

# Reshape data for seaborn
melted_df = df.melt(
    id_vars=[grouping_col],
    value_vars=numeric_cols,
    var_name="Variable",
    value_name="Value"
)

# Use a plain white style
sns.set_theme(style="white")

# Create categorized boxplots
g = sns.catplot(
    x="Variable",
    y="Value",
    col=grouping_col,
    data=melted_df,
    kind="box",
    col_wrap=4,
    height=6,
    aspect=1.2,
    color="white",
    linewidth=1.5,
    dodge=False
)

# Force all box elements to black-and-white
for ax in g.axes.flat:
    for patch in ax.patches:
        patch.set_facecolor("white")
        patch.set_edgecolor("black")
        patch.set_linewidth(1.5)

    for line in ax.lines:
        line.set_color("black")
        line.set_linewidth(1.5)

    ax.grid(False)

# Axis labels and titles
g.set_axis_labels("", "Effect of Sampling Time", fontsize=24, fontweight="bold")
g.set_titles(col_template=r"$\mathbf{{{col_name}}}$", size=24)

# Format x-axis labels
for ax in g.axes.flat:
    ax.tick_params(axis='x', labelrotation=90, labelsize=24)
    for label in ax.get_xticklabels():
        label.set_fontweight('bold')

# Y-axis formatting to 1 decimal place
for ax in g.axes.flat:
    ax.set_yticks([-0.2, -0.1, 0.0, 0.1, 0.2])
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax.set_ylim(-0.20, 0.25)
    ax.tick_params(axis='y', labelsize=24)

# Remove legend if it exists
if g._legend is not None:
    g._legend.remove()

# Optimize layout
plt.tight_layout()

# Save figure
output_path = "C:/Users/achie/Desktop/Box_plot/Time_Boxplot.png"
g.savefig(output_path, dpi=300, facecolor="white")

# Show plot
plt.show()