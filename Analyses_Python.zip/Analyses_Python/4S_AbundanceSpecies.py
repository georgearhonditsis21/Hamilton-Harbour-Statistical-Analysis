from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import warnings

# Suppress FutureWarnings from seaborn
warnings.simplefilter(action='ignore', category=FutureWarning)

def plot_abundance_by_year_common_name(input_file, encoding='utf-8'):
    # Read the dataset
    df = pd.read_csv(input_file, encoding=encoding)

    # Ensure 'Year' is numeric
    df['Year'] = pd.to_numeric(df['Year'], errors='coerce')

    # Replace infinite values with NaN and drop them
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.dropna(subset=['Abundance'], inplace=True)

    # Summarize Abundance per Year categorized by Common Name
    summary_df = df.groupby(['Year', 'Common.Name'], as_index=False)['Abundance'].sum()

    # Get the top 24 most abundant species
    top_species = summary_df.groupby('Common.Name')['Abundance'].sum().nlargest(24).index
    summary_df = summary_df[summary_df['Common.Name'].isin(top_species)]

    # Set seaborn style without grid lines
    sns.set_style("white")

    # Determine global x-axis limits and ticks with interval of 5
    min_year = summary_df['Year'].min()
    max_year = summary_df['Year'].max()
    x_ticks = np.arange(min_year, max_year + 1, step=5)

    # Define subplot layout (3 rows, 4 columns for 12 subplots per figure)
    rows, cols = 3, 4
    num_subplots = rows * cols

    for fig_idx in range(2):  # Two figures, each with 12 subplots
        fig, axes = plt.subplots(rows, cols, figsize=(18, 15))
        axes = axes.flatten()

        species_subset = top_species[fig_idx * num_subplots: (fig_idx + 1) * num_subplots]
        bottom_row_indices = range((rows - 1) * cols, rows * cols)

        for i, species in enumerate(species_subset):
            species_data = summary_df[summary_df['Common.Name'] == species].sort_values('Year')
            sns.lineplot(data=species_data, x='Year', y='Abundance', marker='o', ax=axes[i], linewidth=2.5, markersize=8)
            axes[i].set_title(species, fontsize=20, fontweight='bold')

            # Standardize x-axis
            axes[i].set_xlim(min_year, max_year)
            axes[i].set_xticks(x_ticks)

            # Show tick labels only on bottom row
            if i not in bottom_row_indices:
                axes[i].set_xticklabels([])

            # Format ticks for both x and y axes
            axes[i].tick_params(axis='x', labelsize=18, rotation=45, length=4, width=1, bottom=True, top=False)  # x-axis with tick marks
            axes[i].tick_params(axis='y', labelsize=18, length=4, width=1, left=True, right=False)  # y-axis with tick marks

            # Remove individual axis labels
            axes[i].set_xlabel('')
            axes[i].set_ylabel('')

            # Remove grid lines
            axes[i].grid(False)

        # Shared axis labels
        fig.supxlabel('Year', fontsize=20, fontweight='bold', x=0.5, y=0.01)
        fig.supylabel('Abundance', fontsize=20, fontweight='bold', y=0.5, x=0.01)

        # Hide unused axes
        for j in range(i + 1, len(axes)):
            fig.delaxes(axes[j])

        plt.tight_layout(pad=3.0)
        plt.show()

# File path
BASE_DIR = Path(__file__).resolve().parent

CSV_PATH = BASE_DIR /"HH_Ab_SumYearSpecie.csv"
encoding = 'latin1'

# Run the function
plot_abundance_by_year_common_name(CSV_PATH, encoding)
