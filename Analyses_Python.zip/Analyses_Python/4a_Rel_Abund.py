import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

def plot_abundance_comparison(
    input_file: str,
    encoding: str = "utf-8",
    year_min: int | None = None,
    year_max: int | None = None,
    output_file: str | None = None,
    dpi: int = 300,
):
    """
    Creates a 1x2 figure:
      (left)  continuous absolute summed Abundance by Year, separated by Trophic
      (right) continuous relative Abundance (%) by Year, separated by Trophic

    Missing years are filled and linearly interpolated PER trophic guild.
    """

    # -------------------------
    # Colour-blind-safe palette (Okabe–Ito) + markers
    # -------------------------
    okabe_ito = {
        "Detritivore": "#000000",  # black
        "Planktivore": "#E41A1C",  # vivid red
        "Herbivore":   "#FF7F00",  # orange
        "Invertivore": "#A65628",  # brown (replaces green)
        "Piscivore":   "#FFD700",  # gold/yellow
    }

    diet_marker_map = {
        "Detritivore": "o",
        "Planktivore": "s",
        "Herbivore":   "^",
        "Invertivore": "D",
        "Piscivore":   "X",
    }

    try:
        # -------------------------
        # Read + validate
        # -------------------------
        df = pd.read_csv(input_file, encoding=encoding)

        required_columns = ["Year", "Trophic", "Abundance"]
        missing = [c for c in required_columns if c not in df.columns]
        if missing:
            raise KeyError(f"Missing columns: {', '.join(missing)}")

        df["Year"] = pd.to_numeric(df["Year"], errors="coerce")
        df["Abundance"] = pd.to_numeric(df["Abundance"], errors="coerce")
        df = df.dropna(subset=["Year", "Abundance", "Trophic"]).copy()
        df["Year"] = df["Year"].astype(int)

        if year_min is not None:
            df = df[df["Year"] >= year_min]
        if year_max is not None:
            df = df[df["Year"] <= year_max]

        if df.empty:
            raise ValueError("No data remaining after filtering.")

        # -------------------------
        # Summarize
        # -------------------------
        summary = (
            df.groupby(["Year", "Trophic"], as_index=False)["Abundance"]
              .sum()
        )

        trophic_order = sorted(summary["Trophic"].unique())
        year_range = range(summary["Year"].min(), summary["Year"].max() + 1)

        # -------------------------
        # Fill missing years + interpolate (CONTINUOUS LINES)
        # -------------------------
        filled = []

        for t in trophic_order:
            s = (
                summary[summary["Trophic"] == t]
                .set_index("Year")
                .reindex(year_range)
            )

            s["Trophic"] = t

            # Linear interpolation
            s["Abundance"] = s["Abundance"].interpolate(
                method="linear",
                limit_direction="both"
            )

            filled.append(s.reset_index())

        summary = pd.concat(filled, ignore_index=True)

        # Recompute relative % AFTER interpolation
        total_per_year = summary.groupby("Year")["Abundance"].transform("sum")
        summary["Relative Abundance (%)"] = (summary["Abundance"] / total_per_year) * 100

        # -------------------------
        # Plot
        # -------------------------
        fig, axes = plt.subplots(1, 2, figsize=(18, 7), sharex=True)

        for ax in axes:
            ax.grid(False)
            ax.tick_params(axis="x", rotation=45, labelsize=16)
            ax.tick_params(axis="y", labelsize=16)

        # Absolute Abundance
        for t in trophic_order:
            d = summary[summary["Trophic"] == t].sort_values("Year")
            axes[0].plot(
                d["Year"],
                d["Abundance"],
                color=okabe_ito.get(t, "#333333"),
                marker=diet_marker_map.get(t, "o"),
                linewidth=2.5,
                markersize=8,
                markeredgecolor="black",
                markeredgewidth=0.8,
                label=t,
            )

        #axes[0].set_title("Trends in Absolute Abundance", fontsize=20, fontweight="bold")
        axes[0].set_xlabel("Year", fontsize=18, fontweight="bold")
        axes[0].set_ylabel("Total Abundance", fontsize=18, fontweight="bold")

        # Relative Abundance (%)
        for t in trophic_order:
            d = summary[summary["Trophic"] == t].sort_values("Year")
            axes[1].plot(
                d["Year"],
                d["Relative Abundance (%)"],
                color=okabe_ito.get(t, "#333333"),
                marker=diet_marker_map.get(t, "o"),
                linewidth=2.5,
                markersize=8,
                markeredgecolor="black",
                markeredgewidth=0.8,
            )

        #axes[1].set_title("Trends in Relative Abundance (%)", fontsize=20, fontweight="bold")
        axes[1].set_xlabel("Year", fontsize=18, fontweight="bold")
        axes[1].set_ylabel("Relative Abundance (%)", fontsize=18, fontweight="bold")

        # Shared legend
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(
            handles,
            labels,
            title="Trophic Class",
            loc="center right",
            frameon=False,
            fontsize=14,
            title_fontsize=14,
        )

        plt.tight_layout(rect=[0, 0, 0.88, 1])

        if output_file:
            plt.savefig(output_file, dpi=dpi, bbox_inches="tight")
            plt.close(fig)
            print(f"Saved figure to: {output_file}")
        else:
            plt.show()

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    BASE_DIR = Path(__file__).resolve().parent
    input_file = BASE_DIR /"HH_YearSpecie.csv"

    plot_abundance_comparison(
        input_file=input_file,
        encoding="latin1",
        year_min=None,
        year_max=None,
        output_file=None,
    )
